import React from 'react';
import { Trophy, Award, Flame, MapPin, X } from 'lucide-react';
import { User } from '../../types';
import { getUsers } from '../../utils/auth';

interface LeaderboardProps {
  isOpen: boolean;
  onClose: () => void;
}

const Leaderboard: React.FC<LeaderboardProps> = ({ isOpen, onClose }) => {
  const users = getUsers().sort((a, b) => b.points - a.points);
  const topUsers = users.slice(0, 10);

  const getRankIcon = (rank: number) => {
    if (rank === 1) return '🥇';
    if (rank === 2) return '🥈';
    if (rank === 3) return '🥉';
    return `${rank}`;
  };

  const getRankColor = (rank: number) => {
    if (rank === 1) return 'text-yellow-600 bg-yellow-50';
    if (rank === 2) return 'text-gray-600 bg-gray-50';
    if (rank === 3) return 'text-orange-600 bg-orange-50';
    return 'text-gray-700 bg-white';
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl p-8 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-3">
            <Trophy className="text-yellow-500" size={32} />
            <div>
              <h2 className="text-3xl font-bold text-gray-800">లీడర్‌బోర్డ్</h2>
              <p className="text-gray-600">టాప్ కుకింగ్ మాస్టర్స్</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        <div className="space-y-4">
          {topUsers.map((user, index) => (
            <div
              key={user.id}
              className={`flex items-center justify-between p-4 rounded-xl border-2 transition-all hover:shadow-lg ${getRankColor(index + 1)}`}
            >
              <div className="flex items-center space-x-4">
                <div className="text-2xl font-bold w-12 text-center">
                  {getRankIcon(index + 1)}
                </div>
                <div>
                  <h3 className="text-lg font-bold">{user.username}</h3>
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <MapPin size={14} />
                    <span>{user.region}</span>
                  </div>
                </div>
              </div>

              <div className="text-right">
                <div className="flex items-center space-x-4">
                  <div className="text-center">
                    <div className="flex items-center space-x-1 text-orange-500">
                      <Award size={16} />
                      <span className="font-bold text-lg">{user.points}</span>
                    </div>
                    <div className="text-xs text-gray-500">పాయింట్లు</div>
                  </div>
                  <div className="text-center">
                    <div className="flex items-center space-x-1 text-red-500">
                      <Flame size={16} />
                      <span className="font-bold text-lg">{user.streak}</span>
                    </div>
                    <div className="text-xs text-gray-500">స్ట్రీక్</div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {topUsers.length === 0 && (
          <div className="text-center py-12">
            <Trophy className="mx-auto mb-4 text-gray-300" size={64} />
            <p className="text-gray-500">ఇంకా ఎవరూ రెసిపీలు పోస్ట్ చేయలేదు!</p>
            <p className="text-gray-400 text-sm mt-2">మీరే మొదటివారు అవ్వండి! 🚀</p>
          </div>
        )}

        <div className="mt-8 bg-gradient-to-r from-orange-50 to-yellow-50 p-6 rounded-xl border border-orange-200">
          <h3 className="font-bold text-orange-800 mb-2">🏆 పాయింట్స్ సిస్టమ్:</h3>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="flex items-center space-x-2">
              <span>📝</span>
              <span className="text-gray-700">వచనం: 10 పాయింట్లు</span>
            </div>
            <div className="flex items-center space-x-2">
              <span>🖼️</span>
              <span className="text-gray-700">చిత్రం: 20 పాయింట్లు</span>
            </div>
            <div className="flex items-center space-x-2">
              <span>🎤</span>
              <span className="text-gray-700">ఆడియో: 25 పాయింట్లు</span>
            </div>
            <div className="flex items-center space-x-2">
              <span>🎞️</span>
              <span className="text-gray-700">వీడియో: 30 పాయింట్లు</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Leaderboard;