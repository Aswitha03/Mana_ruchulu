import React, { useState } from 'react';
import { PenTool, Image, Mic, Video, Upload, MapPin, Award } from 'lucide-react';
import { Recipe, User } from '../../types';
import { saveRecipe, getPointsForType, validateTeluguContent, getUserLocation } from '../../utils/recipes';
import { updateUser } from '../../utils/auth';

interface RecipeFormProps {
  user: User;
  onRecipeAdded: (recipe: Recipe) => void;
  onUserUpdated: (user: User) => void;
}

const RecipeForm: React.FC<RecipeFormProps> = ({ user, onRecipeAdded, onUserUpdated }) => {
  const [activeTab, setActiveTab] = useState<'text' | 'image' | 'audio' | 'video'>('text');
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const tabs = [
    { id: 'text', label: 'వచనం', icon: PenTool, points: 10 },
    { id: 'image', label: 'చిత్రం', icon: Image, points: 20 },
    { id: 'audio', label: 'ఆడియో', icon: Mic, points: 25 },
    { id: 'video', label: 'వీడియో', icon: Video, points: 30 }
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');

    if (!title.trim() || !content.trim()) {
      setMessage('దయచేసి అన్ని ఫీల్డ్‌లను పూరించండి');
      setLoading(false);
      return;
    }

    if (!validateTeluguContent(title) || !validateTeluguContent(content)) {
      setMessage('దయచేసి తెలుగులో మాత్రమే వ్రాయండి');
      setLoading(false);
      return;
    }

    try {
      const location = await getUserLocation();
      const points = getPointsForType(activeTab);
      
      const recipe: Recipe = {
        id: Date.now().toString(),
        userId: user.id,
        username: user.username,
        title: title.trim(),
        content: content.trim(),
        type: activeTab,
        region: location,
        points,
        createdAt: new Date().toISOString(),
        likes: 0,
        fileUrl: file ? URL.createObjectURL(file) : undefined
      };

      saveRecipe(recipe);
      
      // Update user points and streak
      const today = new Date().toDateString();
      const lastContribution = user.lastContribution ? new Date(user.lastContribution).toDateString() : '';
      const isConsecutiveDay = lastContribution === new Date(Date.now() - 86400000).toDateString();
      
      const updatedUser = {
        ...user,
        points: user.points + points,
        streak: lastContribution === today ? user.streak : (isConsecutiveDay ? user.streak + 1 : 1),
        lastContribution: new Date().toISOString()
      };

      updateUser(updatedUser);
      onUserUpdated(updatedUser);
      onRecipeAdded(recipe);

      setTitle('');
      setContent('');
      setFile(null);
      setMessage(`విజయవంతంగా జోడించబడింది! మీరు ${points} పాయింట్లు సంపాదించారు! 🎉`);
      
      setTimeout(() => setMessage(''), 3000);
    } catch (error) {
      setMessage('ఏదో తప్పు జరిగింది. దయచేసి మళ్లీ ప్రయత్నించండి.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg p-6 mb-8 border-l-4 border-orange-400">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-800">కొత్త వంటకం పంచుకోండి</h2>
        <div className="text-right">
          <div className="text-sm text-gray-600">మీ స్ట్రీక్</div>
          <div className="text-2xl font-bold text-orange-500">{user.streak} 🔥</div>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`p-4 rounded-lg border-2 transition-all transform hover:scale-105 ${
              activeTab === tab.id
                ? 'border-orange-400 bg-orange-50 text-orange-600'
                : 'border-gray-200 bg-gray-50 text-gray-600 hover:border-orange-200'
            }`}
          >
            <tab.icon className="mx-auto mb-2" size={24} />
            <div className="text-sm font-medium">{tab.label}</div>
            <div className="flex items-center justify-center mt-1">
              <Award size={12} className="mr-1" />
              <span className="text-xs">{tab.points}</span>
            </div>
          </button>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            వంటకం పేరు *
          </label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="ఉదా: అమ్మ చేసిన పెసరట్టు రెసిపీ"
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:border-transparent transition-all"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            వంటకం వివరణ *
          </label>
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="మీ వంటక రెసిపీని తెలుగులో వివరంగా వ్రాయండి..."
            rows={6}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:border-transparent transition-all resize-none"
            required
          />
        </div>

        {activeTab !== 'text' && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {activeTab === 'image' && 'చిత్రం అప్‌లోడ్ చేయండి'}
              {activeTab === 'audio' && 'ఆడియో ఫైల్ అప్‌లోడ్ చేయండి'}
              {activeTab === 'video' && 'వీడియో ఫైల్ అప్‌లోడ్ చేయండి'}
            </label>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-orange-400 transition-colors">
              <Upload className="mx-auto mb-2 text-gray-400" size={32} />
              <input
                type="file"
                accept={
                  activeTab === 'image' ? 'image/*' :
                  activeTab === 'audio' ? 'audio/*' :
                  'video/*'
                }
                onChange={(e) => setFile(e.target.files?.[0] || null)}
                className="hidden"
                id="file-upload"
              />
              <label
                htmlFor="file-upload"
                className="cursor-pointer text-orange-500 hover:text-orange-600 font-medium"
              >
                ఫైల్ ఎంచుకోండి
              </label>
              {file && (
                <p className="mt-2 text-sm text-gray-600">{file.name}</p>
              )}
            </div>
          </div>
        )}

        {message && (
          <div className={`p-4 rounded-lg text-center ${
            message.includes('విజయవంతంగా') ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
          }`}>
            {message}
          </div>
        )}

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-gradient-to-r from-orange-400 to-red-500 text-white py-4 rounded-lg font-semibold hover:from-orange-500 hover:to-red-600 transition-all transform hover:scale-105 disabled:opacity-50 disabled:transform-none flex items-center justify-center space-x-2"
        >
          {loading ? (
            <span>అప్‌లోడ్ చేస్తున్నాం...</span>
          ) : (
            <>
              <Upload size={20} />
              <span>వంటకం పంచుకోండi ({getPointsForType(activeTab)} పాయింట్లు)</span>
            </>
          )}
        </button>
      </form>

      <div className="mt-6 bg-yellow-50 p-4 rounded-lg border border-yellow-200">
        <h3 className="font-semibold text-yellow-800 mb-2">💡 చిట్కా:</h3>
        <p className="text-yellow-700 text-sm">
          మీ అమ్మ చెప్పిన రహస్య పచ్చడి రెసిపీ అప్‌లోడ్ చేయండి! వివరంగా వ్రాస్తే మరింత పాయింట్లు మిలుస్తాయి. 😊
        </p>
      </div>
    </div>
  );
};

export default RecipeForm;