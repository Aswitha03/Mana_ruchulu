import React, { useState } from 'react';
import { X, User, Mail, MapPin, Eye, EyeOff } from 'lucide-react';
import { register, login, setCurrentUser } from '../../utils/auth';
import { getUserLocation } from '../../utils/recipes';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin: (user: any) => void;
}

const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onLogin }) => {
  const [isLoginMode, setIsLoginMode] = useState(true);
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    region: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');

    try {
      if (isLoginMode) {
        const result = login(formData.email, formData.password);
        if (result.success && result.user) {
          setCurrentUser(result.user);
          onLogin(result.user);
          onClose();
        } else {
          setMessage(result.message);
        }
      } else {
        const location = formData.region || await getUserLocation();
        const result = register(formData.username, formData.email, formData.password, location);
        if (result.success && result.user) {
          setCurrentUser(result.user);
          onLogin(result.user);
          onClose();
        } else {
          setMessage(result.message);
        }
      }
    } catch (error) {
      setMessage('ఏదో తప్పు జరిగింది. దయచేసి మళ్లీ ప్రయత్నించండి.');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl p-8 w-full max-w-md relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-orange-400 via-yellow-400 to-green-500"></div>
        
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700 transition-colors"
        >
          <X size={24} />
        </button>

        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-800 mb-2">
            మన రుచులు
          </h2>
          <p className="text-gray-600">
            {isLoginMode ? 'మీ ఖాతాలో ప్రవేశించండి' : 'కొత్త ఖాతా సృష్టించండి'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {!isLoginMode && (
            <div className="relative">
              <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
              <input
                type="text"
                value={formData.username}
                onChange={(e) => setFormData({...formData, username: e.target.value})}
                placeholder="వినియోగదారు పేరు"
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:border-transparent transition-all"
                required
              />
            </div>
          )}

          <div className="relative">
            <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({...formData, email: e.target.value})}
              placeholder="ఇమెయిల్"
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:border-transparent transition-all"
              required
            />
          </div>

          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              value={formData.password}
              onChange={(e) => setFormData({...formData, password: e.target.value})}
              placeholder="పాస్‌వర్డ్"
              className="w-full pl-4 pr-12 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:border-transparent transition-all"
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
            >
              {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
            </button>
          </div>

          {!isLoginMode && (
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
              <input
                type="text"
                value={formData.region}
                onChange={(e) => setFormData({...formData, region: e.target.value})}
                placeholder="మీ ప్రాంతం (ఐచ్ఛికం)"
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:border-transparent transition-all"
              />
            </div>
          )}

          {message && (
            <div className="text-red-600 text-center text-sm bg-red-50 p-3 rounded-lg">
              {message}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-orange-400 to-red-500 text-white py-3 rounded-lg font-semibold hover:from-orange-500 hover:to-red-600 transition-all transform hover:scale-105 disabled:opacity-50 disabled:transform-none"
          >
            {loading ? 'దయచేసి వేచి ఉండండి...' : (isLoginMode ? 'లాగిన్' : 'నమోదు')}
          </button>
        </form>

        <div className="text-center mt-6">
          <button
            onClick={() => setIsLoginMode(!isLoginMode)}
            className="text-orange-500 hover:text-orange-600 transition-colors"
          >
            {isLoginMode ? 'కొత్త ఖాతా సృష్టించండి' : 'ఇప్పటికే ఖాతా ఉందా? లాగిన్ చేయండి'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AuthModal;