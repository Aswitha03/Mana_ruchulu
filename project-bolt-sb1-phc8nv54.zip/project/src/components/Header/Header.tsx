import React from 'react';
import { ChefHat, User, Trophy, LogOut } from 'lucide-react';
import { User as UserType } from '../../types';

interface HeaderProps {
  user: UserType | null;
  onAuthClick: () => void;
  onLogout: () => void;
  onProfileClick: () => void;
  onLeaderboardClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ 
  user, 
  onAuthClick, 
  onLogout, 
  onProfileClick, 
  onLeaderboardClick 
}) => {
  return (
    <header className="bg-gradient-to-r from-orange-400 via-yellow-400 to-green-500 shadow-lg">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <ChefHat className="text-white" size={32} />
            <div>
              <h1 className="text-2xl font-bold text-white">మన రుచులు</h1>
              <p className="text-orange-100 text-sm">తెలుగు వంటకాల అందమైన ప్రపంచం</p>
            </div>
          </div>

          <nav className="flex items-center space-x-4">
            {user ? (
              <>
                <button
                  onClick={onLeaderboardClick}
                  className="flex items-center space-x-2 bg-white bg-opacity-20 text-white px-4 py-2 rounded-lg hover:bg-opacity-30 transition-all"
                >
                  <Trophy size={18} />
                  <span>లీడర్‌బోర్డ్</span>
                </button>
                
                <button
                  onClick={onProfileClick}
                  className="flex items-center space-x-2 bg-white bg-opacity-20 text-white px-4 py-2 rounded-lg hover:bg-opacity-30 transition-all"
                >
                  <User size={18} />
                  <span>{user.username}</span>
                  <span className="bg-yellow-400 text-yellow-900 px-2 py-1 rounded-full text-xs font-bold">
                    {user.points}
                  </span>
                </button>
                
                <button
                  onClick={onLogout}
                  className="flex items-center space-x-2 bg-red-500 bg-opacity-80 text-white px-4 py-2 rounded-lg hover:bg-opacity-100 transition-all"
                >
                  <LogOut size={18} />
                  <span>లాగౌట్</span>
                </button>
              </>
            ) : (
              <button
                onClick={onAuthClick}
                className="bg-white text-orange-500 px-6 py-2 rounded-lg font-semibold hover:bg-orange-50 transition-all transform hover:scale-105"
              >
                లాగిన్ / రిజిస్టర్
              </button>
            )}
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;