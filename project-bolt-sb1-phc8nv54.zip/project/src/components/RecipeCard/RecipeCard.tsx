import React from 'react';
import { Heart, Download, MapPin, Award, Clock, User } from 'lucide-react';
import { Recipe } from '../../types';

interface RecipeCardProps {
  recipe: Recipe;
  onDownload: (recipe: Recipe) => void;
}

const RecipeCard: React.FC<RecipeCardProps> = ({ recipe, onDownload }) => {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('te-IN');
  };

  const getTypeIcon = (type: string) => {
    const icons = {
      text: '📝',
      image: '🖼️',
      audio: '🎤',
      video: '🎞️'
    };
    return icons[type as keyof typeof icons] || '📝';
  };

  const getTypeName = (type: string) => {
    const names = {
      text: 'వచనం',
      image: 'చిత్రం',
      audio: 'ఆడియో',
      video: 'వీడియో'
    };
    return names[type as keyof typeof names] || 'వచనం';
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg p-6 border-l-4 border-yellow-400 hover:shadow-xl transition-all transform hover:scale-105">
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-2">
            <span className="text-2xl">{getTypeIcon(recipe.type)}</span>
            <span className="text-sm text-gray-600 bg-gray-100 px-2 py-1 rounded-full">
              {getTypeName(recipe.type)}
            </span>
            <div className="flex items-center space-x-1 text-orange-500">
              <Award size={16} />
              <span className="text-sm font-bold">{recipe.points}</span>
            </div>
          </div>
          <h3 className="text-xl font-bold text-gray-800 mb-2">{recipe.title}</h3>
        </div>
        <button
          onClick={() => onDownload(recipe)}
          className="bg-green-500 text-white p-2 rounded-lg hover:bg-green-600 transition-colors"
          title="డౌన్‌లోడ్"
        >
          <Download size={18} />
        </button>
      </div>

      {recipe.fileUrl && recipe.type === 'image' && (
        <div className="mb-4 rounded-lg overflow-hidden">
          <img
            src={recipe.fileUrl}
            alt={recipe.title}
            className="w-full h-48 object-cover"
          />
        </div>
      )}

      <p className="text-gray-700 mb-4 line-clamp-3">{recipe.content}</p>

      <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
        <div className="flex items-center space-x-1">
          <User size={16} />
          <span>{recipe.username}</span>
        </div>
        <div className="flex items-center space-x-1">
          <MapPin size={16} />
          <span>{recipe.region}</span>
        </div>
      </div>

      <div className="flex items-center justify-between pt-4 border-t border-gray-200">
        <div className="flex items-center space-x-1 text-gray-500">
          <Clock size={16} />
          <span>{formatDate(recipe.createdAt)}</span>
        </div>
        <button className="flex items-center space-x-1 text-red-500 hover:text-red-600 transition-colors">
          <Heart size={16} />
          <span>{recipe.likes}</span>
        </button>
      </div>
    </div>
  );
};

export default RecipeCard;