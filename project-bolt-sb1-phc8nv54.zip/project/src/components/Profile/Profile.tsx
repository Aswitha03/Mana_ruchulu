import React from 'react';
import { User, Award, Flame, MapPin, Calendar, X } from 'lucide-react';
import { User as UserType } from '../../types';
import { getRecipes } from '../../utils/recipes';

interface ProfileProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserType;
}

const Profile: React.FC<ProfileProps> = ({ isOpen, onClose, user }) => {
  const userRecipes = getRecipes().filter(recipe => recipe.userId === user.id);
  const totalRecipes = userRecipes.length;
  
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('te-IN');
  };

  const getStreakEmoji = (streak: number) => {
    if (streak >= 30) return '🔥🔥🔥';
    if (streak >= 7) return '🔥🔥';
    if (streak >= 3) return '🔥';
    return '⭐';
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl p-8 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-bold text-gray-800">మీ ప్రొఫైల్</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        <div className="bg-gradient-to-br from-orange-50 to-yellow-50 rounded-2xl p-6 mb-8 border border-orange-200">
          <div className="flex items-center space-x-6">
            <div className="bg-gradient-to-br from-orange-400 to-red-500 text-white rounded-full p-6">
              <User size={48} />
            </div>
            <div>
              <h3 className="text-2xl font-bold text-gray-800">{user.username}</h3>
              <div className="flex items-center space-x-2 text-gray-600 mt-1">
                <MapPin size={16} />
                <span>{user.region}</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-600 mt-1">
                <Calendar size={16} />
                <span>మెంబర్ నుండి: {formatDate(user.joinDate)}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-orange-50 p-4 rounded-xl text-center border border-orange-200">
            <Award className="mx-auto mb-2 text-orange-500" size={24} />
            <div className="text-2xl font-bold text-orange-600">{user.points}</div>
            <div className="text-sm text-gray-600">పాయింట్లు</div>
          </div>
          
          <div className="bg-red-50 p-4 rounded-xl text-center border border-red-200">
            <Flame className="mx-auto mb-2 text-red-500" size={24} />
            <div className="text-2xl font-bold text-red-600">{user.streak}</div>
            <div className="text-sm text-gray-600">స్ట్రీక్</div>
          </div>
          
          <div className="bg-green-50 p-4 rounded-xl text-center border border-green-200">
            <div className="text-2xl mb-2">{getStreakEmoji(user.streak)}</div>
            <div className="text-2xl font-bold text-green-600">{totalRecipes}</div>
            <div className="text-sm text-gray-600">రెసిపీలు</div>
          </div>
          
          <div className="bg-blue-50 p-4 rounded-xl text-center border border-blue-200">
            <div className="text-2xl mb-2">🏆</div>
            <div className="text-2xl font-bold text-blue-600">
              {Math.floor(user.points / 100)}
            </div>
            <div className="text-sm text-gray-600">లెవల్</div>
          </div>
        </div>

        <div className="bg-gray-50 p-6 rounded-xl">
          <h4 className="text-lg font-bold text-gray-800 mb-4">మీ రెసిపీలు</h4>
          {userRecipes.length > 0 ? (
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {userRecipes.map((recipe) => (
                <div key={recipe.id} className="bg-white p-4 rounded-lg border">
                  <div className="flex items-center justify-between">
                    <div>
                      <h5 className="font-semibold text-gray-800">{recipe.title}</h5>
                      <p className="text-sm text-gray-600 mt-1">
                        {formatDate(recipe.createdAt)} - {recipe.points} పాయింట్లు
                      </p>
                    </div>
                    <div className="text-2xl">
                      {recipe.type === 'text' && '📝'}
                      {recipe.type === 'image' && '🖼️'}
                      {recipe.type === 'audio' && '🎤'}
                      {recipe.type === 'video' && '🎞️'}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <div className="text-4xl mb-4">🍽️</div>
              <p className="text-gray-500">ఇంకా రెసిపీలు పోస్ట్ చేయలేదు</p>
              <p className="text-gray-400 text-sm mt-1">మీ మొదటి వంటకం పంచుకోండి!</p>
            </div>
          )}
        </div>

        <div className="mt-6 bg-gradient-to-r from-yellow-50 to-orange-50 p-4 rounded-xl border border-yellow-200">
          <h4 className="font-bold text-yellow-800 mb-2">🌟 చిట్కాలు:</h4>
          <ul className="text-sm text-yellow-700 space-y-1">
            <li>• రోజూ రెసిపీ పోస్ట్ చేసి స్ట్రీక్ పెంచుకోండి</li>
            <li>• వీడియో/ఆడియో రెసిపీలు ఎక్కువ పాయింట్లు ఇస్తాయి</li>
            <li>• 100 పాయింట్లకు ఒక లెవల్ అప్!</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Profile;