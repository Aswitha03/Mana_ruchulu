import { Recipe } from '../types';

const RECIPES_KEY = 'mana_ruchulu_recipes';

export const getRecipes = (): Recipe[] => {
  const recipes = localStorage.getItem(RECIPES_KEY);
  return recipes ? JSON.parse(recipes) : [];
};

export const saveRecipe = (recipe: Recipe): void => {
  const recipes = getRecipes();
  recipes.unshift(recipe);
  localStorage.setItem(RECIPES_KEY, JSON.stringify(recipes));
};

export const getPointsForType = (type: string): number => {
  const pointsMap = {
    text: 10,
    image: 20,
    audio: 25,
    video: 30
  };
  return pointsMap[type as keyof typeof pointsMap] || 0;
};

export const validateTeluguContent = (content: string): boolean => {
  const teluguRegex = /[\u0C00-\u0C7F]/;
  return teluguRegex.test(content);
};

export const getUserLocation = async (): Promise<string> => {
  try {
    const response = await fetch('https://ipapi.co/json/');
    const data = await response.json();
    return `${data.city}, ${data.region}`;
  } catch (error) {
    return 'తెలియని ప్రాంతం';
  }
};