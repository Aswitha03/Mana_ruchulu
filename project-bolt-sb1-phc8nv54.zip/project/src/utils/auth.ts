import { User } from '../types';

const USERS_KEY = 'mana_ruchulu_users';
const CURRENT_USER_KEY = 'mana_ruchulu_current_user';

export const getUsers = (): User[] => {
  const users = localStorage.getItem(USERS_KEY);
  return users ? JSON.parse(users) : [];
};

export const saveUsers = (users: User[]): void => {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
};

export const getCurrentUser = (): User | null => {
  const user = localStorage.getItem(CURRENT_USER_KEY);
  return user ? JSON.parse(user) : null;
};

export const setCurrentUser = (user: User | null): void => {
  if (user) {
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
  } else {
    localStorage.removeItem(CURRENT_USER_KEY);
  }
};

export const register = (username: string, email: string, password: string, region: string): { success: boolean; message: string; user?: User } => {
  const users = getUsers();
  
  if (users.find(u => u.email === email)) {
    return { success: false, message: 'ఈ ఇమెయిల్ ఇప్పటికే ఉపయోగంలో ఉంది' };
  }
  
  if (users.find(u => u.username === username)) {
    return { success: false, message: 'ఈ వినియోగదారు పేరు ఇప్పటికే తీసుకోబడింది' };
  }

  const newUser: User = {
    id: Date.now().toString(),
    username,
    email,
    region,
    points: 0,
    streak: 0,
    lastContribution: '',
    joinDate: new Date().toISOString()
  };

  users.push(newUser);
  saveUsers(users);
  
  return { success: true, message: 'విజయవంతంగా నమోదు చేయబడింది!', user: newUser };
};

export const login = (email: string, password: string): { success: boolean; message: string; user?: User } => {
  const users = getUsers();
  const user = users.find(u => u.email === email);
  
  if (!user) {
    return { success: false, message: 'వినియోగదారు దొరకలేదు' };
  }
  
  return { success: true, message: 'విజయవంతంగా లాగిన్ అయ్యారు!', user };
};

export const updateUser = (updatedUser: User): void => {
  const users = getUsers();
  const index = users.findIndex(u => u.id === updatedUser.id);
  if (index !== -1) {
    users[index] = updatedUser;
    saveUsers(users);
    setCurrentUser(updatedUser);
  }
};