export interface User {
  id: string;
  username: string;
  email: string;
  region: string;
  points: number;
  streak: number;
  lastContribution: string;
  joinDate: string;
  profileImage?: string;
}

export interface Recipe {
  id: string;
  userId: string;
  title: string;
  content: string;
  type: 'text' | 'image' | 'audio' | 'video';
  fileUrl?: string;
  region: string;
  points: number;
  createdAt: string;
  likes: number;
  username: string;
}

export interface LeaderboardEntry {
  user: User;
  rank: number;
}