import React, { useState, useEffect } from 'react';
import Header from './components/Header/Header';
import AuthModal from './components/Auth/AuthModal';
import RecipeForm from './components/RecipeForm/RecipeForm';
import RecipeCard from './components/RecipeCard/RecipeCard';
import Leaderboard from './components/Leaderboard/Leaderboard';
import Profile from './components/Profile/Profile';
import { User, Recipe } from './types';
import { getCurrentUser, setCurrentUser } from './utils/auth';
import { getRecipes } from './utils/recipes';
import { ChefHat, Sparkles } from 'lucide-react';

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const [showProfile, setShowProfile] = useState(false);

  useEffect(() => {
    const currentUser = getCurrentUser();
    if (currentUser) {
      setUser(currentUser);
    }
    setRecipes(getRecipes());
  }, []);

  const handleLogin = (loggedInUser: User) => {
    setUser(loggedInUser);
    setShowAuthModal(false);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setUser(null);
  };

  const handleRecipeAdded = (newRecipe: Recipe) => {
    setRecipes([newRecipe, ...recipes]);
  };

  const handleUserUpdated = (updatedUser: User) => {
    setUser(updatedUser);
  };

  const handleDownload = (recipe: Recipe) => {
    const content = `వంటకం: ${recipe.title}\n\nవంటక విధానం:\n${recipe.content}\n\nవచ్చింది: ${recipe.username}\nప్రాంతం: ${recipe.region}\nతేది: ${new Date(recipe.createdAt).toLocaleDateString('te-IN')}`;
    
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${recipe.title}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-yellow-50">
      <Header
        user={user}
        onAuthClick={() => setShowAuthModal(true)}
        onLogout={handleLogout}
        onProfileClick={() => setShowProfile(true)}
        onLeaderboardClick={() => setShowLeaderboard(true)}
      />

      <main className="container mx-auto px-4 py-8">
        {!user ? (
          <div className="text-center py-16">
            <div className="max-w-2xl mx-auto">
              <div className="flex items-center justify-center mb-8">
                <ChefHat className="text-orange-500 mr-4" size={64} />
                <Sparkles className="text-yellow-500" size={48} />
              </div>
              
              <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">
                మన రుచులకు స్వాగతం! 🍛
              </h1>
              
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                వంటకాలు మరియు భాష కలిసిపోయే అందమైన ప్రపంచం, సంస్కృతి కమ్యూనిటీగా మారే చోటు.
              </p>

              <div className="grid md:grid-cols-2 gap-8 mb-12">
                <div className="bg-white p-6 rounded-2xl shadow-lg border-l-4 border-orange-400">
                  <div className="text-3xl mb-4">📱</div>
                  <h3 className="text-xl font-bold text-gray-800 mb-2">పంచుకోండి & సంపాదించండి</h3>
                  <p className="text-gray-600">మీ అమ్మ చెప్పిన రహస్య రెసిపీలను పంచుకుని పాయింట్లు సంపాదించండి</p>
                </div>
                
                <div className="bg-white p-6 rounded-2xl shadow-lg border-l-4 border-green-400">
                  <div className="text-3xl mb-4">🏆</div>
                  <h3 className="text-xl font-bold text-gray-800 mb-2">లీడర్‌బోర్డ్‌లో మెరుగుపడండి</h3>
                  <p className="text-gray-600">రోజూ కొత్త వంటకాలు పోస్ట్ చేసి టాప్ కుక్ అవ్వండి</p>
                </div>
              </div>

              <div className="bg-gradient-to-r from-orange-100 to-yellow-100 p-6 rounded-2xl border border-orange-200 mb-8">
                <h3 className="text-lg font-bold text-orange-800 mb-4">🎁 పాయింట్స్ సిస్టమ్:</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="text-2xl mb-2">📝</div>
                    <div className="font-semibold">వచనం</div>
                    <div className="text-orange-600">10 పాయింట్లు</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl mb-2">🖼️</div>
                    <div className="font-semibold">చిత్రం</div>
                    <div className="text-orange-600">20 పాయింట్లు</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl mb-2">🎤</div>
                    <div className="font-semibold">ఆడియో</div>
                    <div className="text-orange-600">25 పాయింట్లు</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl mb-2">🎞️</div>
                    <div className="font-semibold">వీడియో</div>
                    <div className="text-orange-600">30 పాయింట్లు</div>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setShowAuthModal(true)}
                className="bg-gradient-to-r from-orange-400 to-red-500 text-white px-12 py-4 rounded-2xl text-xl font-bold hover:from-orange-500 hover:to-red-600 transition-all transform hover:scale-105 shadow-lg"
              >
                ప్రారంభించండి - ఇవ్వాలా! 🚀
              </button>

              <p className="text-gray-500 mt-6">
                "मन भाषा... मन वंत... मन डिजिटल चेप्लु।" <br />
                మన భాష, మన వంట, మన డిజిటల్ చేపలు.
              </p>
            </div>
          </div>
        ) : (
          <>
            <RecipeForm 
              user={user} 
              onRecipeAdded={handleRecipeAdded}
              onUserUpdated={handleUserUpdated}
            />
            
            <div className="mb-8">
              <h2 className="text-3xl font-bold text-gray-800 mb-6 text-center">
                తాజా వంటకాలు 🍽️
              </h2>
              
              {recipes.length > 0 ? (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {recipes.map((recipe) => (
                    <RecipeCard
                      key={recipe.id}
                      recipe={recipe}
                      onDownload={handleDownload}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-16">
                  <div className="text-6xl mb-4">🍽️</div>
                  <h3 className="text-2xl font-bold text-gray-800 mb-2">
                    ఇంకా వంటకాలు లేవు!
                  </h3>
                  <p className="text-gray-600">
                    మీరే మొదటి వంటకం పంచుకోండి! 👆
                  </p>
                </div>
              )}
            </div>
          </>
        )}
      </main>

      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onLogin={handleLogin}
      />

      <Leaderboard
        isOpen={showLeaderboard}
        onClose={() => setShowLeaderboard(false)}
      />

      {user && (
        <Profile
          isOpen={showProfile}
          onClose={() => setShowProfile(false)}
          user={user}
        />
      )}

      <footer className="bg-gradient-to-r from-orange-400 via-yellow-400 to-green-500 text-white py-8 mt-16">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center mb-4">
            <ChefHat size={32} className="mr-3" />
            <h3 className="text-2xl font-bold">మన రుచులు</h3>
          </div>
          <p className="text-orange-100 mb-4">
            తెలుగు వంటకాల అందమైన ప్రపంచం - మన భాష, మన సంస్కృతి, మన రుచులు
          </p>
          <p className="text-orange-200 text-sm">
            © 2025 మన రుచులು. మన భాషకు, మన వంటకాలకు గౌరవంగా తయారైంది. ❤️
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;