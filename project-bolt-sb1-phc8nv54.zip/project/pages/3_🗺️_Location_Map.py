import streamlit as st
import folium
from streamlit_folium import st_folium
import pandas as pd

st.set_page_config(page_title="లొకేషన్ మ్యాప్ - మన రుచులు", page_icon="🗺️")

def main():
    st.markdown("""
    <div style="background: linear-gradient(135deg, #2D5A27, #4CAF50); color: white; padding: 2rem; border-radius: 15px; text-align: center; margin-bottom: 2rem;">
        <h1>🗺️ లొకేషన్ మ్యాప్</h1>
        <p>ప్రాంతవారీ వంటకాలను అన్వేషించండి</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Create a map centered on Andhra Pradesh/Telangana
    m = folium.Map(location=[15.9129, 79.7400], zoom_start=7)
    
    # Group recipes by location
    location_recipes = {}
    for recipe in st.session_state.recipes:
        location = recipe['location']
        if location not in location_recipes:
            location_recipes[location] = []
        location_recipes[location].append(recipe)
    
    # Sample coordinates for major cities (in real app, you'd use geocoding)
    sample_locations = {
        'Hyderabad, Telangana': [17.3850, 78.4867],
        'Vijayawada, Andhra Pradesh': [16.5062, 80.6480],
        'Visakhapatnam, Andhra Pradesh': [17.6868, 83.2185],
        'Tirupati, Andhra Pradesh': [13.6288, 79.4192],
        'Warangal, Telangana': [17.9689, 79.5941],
        'Guntur, Andhra Pradesh': [16.3067, 80.4365],
        'Nellore, Andhra Pradesh': [14.4426, 79.9865],
        'Kurnool, Andhra Pradesh': [15.8281, 78.0373],
        'Rajahmundry, Andhra Pradesh': [17.0005, 81.8040],
        'Karimnagar, Telangana': [18.4386, 79.1288]
    }
    
    # Add markers for locations with recipes
    for location, coords in sample_locations.items():
        if location in location_recipes:
            recipes_count = len(location_recipes[location])
            
            # Create popup content
            popup_html = f"""
            <div style="width: 200px;">
                <h4>📍 {location}</h4>
                <p><b>🍽️ {recipes_count} వంటకాలు</b></p>
                <hr>
            """
            
            # Add top recipes from this location
            for recipe in location_recipes[location][:3]:
                user = st.session_state.users.get(recipe['user_id'], {})
                popup_html += f"""
                <div style="margin: 5px 0; padding: 5px; background: #f0f0f0; border-radius: 5px;">
                    <b>{recipe['title']}</b><br>
                    <small>👤 {user.get('username', 'Unknown')} | ⭐ {recipe['points']} పాయింట్లు</small>
                </div>
                """
            
            popup_html += "</div>"
            
            # Determine marker color based on recipe count
            if recipes_count >= 10:
                color = 'red'
            elif recipes_count >= 5:
                color = 'orange'
            else:
                color = 'green'
            
            folium.Marker(
                coords,
                popup=folium.Popup(popup_html, max_width=300),
                icon=folium.Icon(color=color, icon='cutlery', prefix='fa'),
                tooltip=f"{location} - {recipes_count} వంటకాలు"
            ).add_to(m)
    
    # Display map
    col1, col2 = st.columns([3, 1])
    
    with col1:
        map_data = st_folium(m, width=700, height=500)
    
    with col2:
        st.markdown("### 🎨 మ్యాప్ లెజెండ్")
        st.markdown("""
        <div style="background: white; padding: 1rem; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            <div style="margin: 10px 0;">
                <span style="color: red; font-size: 20px;">🔴</span> 10+ వంటకాలు
            </div>
            <div style="margin: 10px 0;">
                <span style="color: orange; font-size: 20px;">🟠</span> 5-9 వంటకాలు
            </div>
            <div style="margin: 10px 0;">
                <span style="color: green; font-size: 20px;">🟢</span> 1-4 వంటకాలు
            </div>
        </div>
        """, unsafe_allow_html=True)
        
        # Location statistics
        st.markdown("### 📊 లొకేషన్ గణాంకాలు")
        if location_recipes:
            location_stats = []
            for location, recipes in location_recipes.items():
                location_stats.append({
                    'ప్రాంతం': location,
                    'వంటకాలు': len(recipes),
                    'మొత్తం పాయింట్లు': sum(r['points'] for r in recipes)
                })
            
            df = pd.DataFrame(location_stats)
            df = df.sort_values('వంటకాలు', ascending=False)
            st.dataframe(df, use_container_width=True)
    
    # Show recipes from selected location
    if map_data.get('last_object_clicked_popup'):
        st.markdown("### 🍽️ ఎంచుకున్న ప్రాంతపు వంటకాలు")
        
        # Extract location from popup (simplified)
        # In a real app, you'd parse the popup content properly
        selected_recipes = []
        for location, recipes in location_recipes.items():
            if len(recipes) > 0:  # Show first location's recipes as example
                selected_recipes = recipes
                break
        
        if selected_recipes:
            for recipe in selected_recipes:
                user = st.session_state.users.get(recipe['user_id'], {})
                
                with st.container():
                    st.markdown(f"""
                    <div style="background: white; border-radius: 15px; padding: 1.5rem; margin: 1rem 0; box-shadow: 0 4px 20px rgba(0,0,0,0.1); border-left: 5px solid #F7931E;">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <h4>{recipe['title']}</h4>
                                <p>👤 {user.get('username', 'Unknown')} | 📍 {recipe['location']} | 📅 {recipe['created_at'][:10]}</p>
                                <p>{recipe['content'][:150]}...</p>
                            </div>
                            <div style="text-align: center;">
                                <div style="font-size: 2rem;">{get_type_emoji(recipe['type'])}</div>
                                <div><b>⭐ {recipe['points']}</b> పాయింట్లు</div>
                            </div>
                        </div>
                    </div>
                    """, unsafe_allow_html=True)
    
    # Regional specialties
    st.markdown("### 🏛️ ప్రాంతీయ ప్రత్యేకతలు")
    
    regional_info = {
        'హైదరాబాద్': {
            'specialties': ['బిర్యానీ', 'హలీమ్', 'దబ్బా గోష్త్'],
            'description': 'నిజాముల వంటకాలకు ప్రసిద్ధి'
        },
        'విజయవాడ': {
            'specialties': ['పులిహోర', 'గుంటూరు కారం', 'అవకాయ'],
            'description': 'కృష్ణా జిల్లా సాంప్రదాయ వంటకాలు'
        },
        'విశాఖపట్నం': {
            'specialties': ['చేప కూర', 'రోయ్యల కూర', 'చేప పులుసు'],
            'description': 'సముద్రతీర వంటకాలకు ప్రసిద్ధి'
        }
    }
    
    cols = st.columns(3)
    for i, (region, info) in enumerate(regional_info.items()):
        with cols[i]:
            st.markdown(f"""
            <div style="background: linear-gradient(135deg, #FFE5B4, #FFCC70); border-radius: 15px; padding: 1.5rem; text-align: center; height: 200px;">
                <h4>🏛️ {region}</h4>
                <p style="font-size: 0.9rem; margin: 10px 0;">{info['description']}</p>
                <div style="margin-top: 15px;">
                    {'<br>'.join([f"• {specialty}" for specialty in info['specialties']])}
                </div>
            </div>
            """, unsafe_allow_html=True)

def get_type_emoji(recipe_type):
    emojis = {
        'text': '📝',
        'image': '🖼️',
        'audio': '🎤',
        'video': '🎞️'
    }
    return emojis.get(recipe_type, '📝')

if __name__ == "__main__":
    main()