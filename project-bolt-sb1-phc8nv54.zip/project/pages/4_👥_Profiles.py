import streamlit as st
import pandas as pd
from datetime import datetime

st.set_page_config(page_title="ప్రొఫైల్స్ - మన రుచులు", page_icon="👥")

def main():
    st.markdown("""
    <div style="background: linear-gradient(135deg, #4CAF50, #2D5A27); color: white; padding: 2rem; border-radius: 15px; text-align: center; margin-bottom: 2rem;">
        <h1>👥 కమ్యూనిటీ ప్రొఫైల్స్</h1>
        <p>మన వంటకాల కమ్యూనిటీ సభ్యులను కలుసుకోండి</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Search and filter options
    col1, col2, col3 = st.columns([2, 1, 1])
    with col1:
        search_term = st.text_input("🔍 వినియోగదారుని వెతకండి", placeholder="పేరు లేదా ప్రాంతం వ్రాయండి...")
    with col2:
        sort_by = st.selectbox("🔄 క్రమబద్ధీకరణ", ["పాయింట్లు", "రెసిపీలు", "స్ట్రీక్", "తేది"])
    with col3:
        view_mode = st.selectbox("👁️ వ్యూ మోడ్", ["కార్డ్ వ్యూ", "లిస్ట్ వ్యూ"])
    
    # Get all users and sort
    users_list = list(st.session_state.users.items())
    
    if sort_by == "పాయింట్లు":
        users_list.sort(key=lambda x: x[1]['points'], reverse=True)
    elif sort_by == "రెసిపీలు":
        users_list.sort(key=lambda x: len([r for r in st.session_state.recipes if r['user_id'] == x[0]]), reverse=True)
    elif sort_by == "స్ట్రీక్":
        users_list.sort(key=lambda x: x[1]['streak'], reverse=True)
    elif sort_by == "తేది":
        users_list.sort(key=lambda x: x[1].get('created_at', ''), reverse=True)
    
    # Filter users based on search
    filtered_users = []
    for user_id, user in users_list:
        if not search_term or (
            search_term.lower() in user['username'].lower() or 
            search_term.lower() in user['region'].lower()
        ):
            filtered_users.append((user_id, user))
    
    # Display users
    if view_mode == "కార్డ్ వ్యూ":
        show_card_view(filtered_users)
    else:
        show_list_view(filtered_users)

def show_card_view(users_list):
    # Display user profiles in card format
    cols = st.columns(2)
    
    for i, (user_id, user) in enumerate(users_list):
        user_recipes = [r for r in st.session_state.recipes if r['user_id'] == user_id]
        
        with cols[i % 2]:
            # User card
            st.markdown(f"""
            <div style="background: white; border-radius: 15px; padding: 1.5rem; margin: 1rem 0; box-shadow: 0 4px 20px rgba(0,0,0,0.1); border-left: 5px solid #F7931E;">
                <div style="display: flex; align-items: center; margin-bottom: 1rem;">
                    <div style="background: linear-gradient(135deg, #FF6B35, #F7931E); color: white; border-radius: 50%; width: 60px; height: 60px; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; margin-right: 1rem;">
                        👤
                    </div>
                    <div>
                        <h4 style="margin: 0;">{user['username']}</h4>
                        <p style="margin: 0; color: #666;">📍 {user['region']}</p>
                        <p style="margin: 0; color: #666; font-size: 0.8rem;">🗓️ {user.get('created_at', '')[:10]}</p>
                    </div>
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin: 1rem 0;">
                    <div style="text-align: center; background: #FFF3E0; padding: 10px; border-radius: 8px;">
                        <div style="font-weight: bold; color: #FF6B35;">#{get_user_rank(user_id)}</div>
                        <div style="font-size: 0.8rem; color: #666;">ర్యాంక్</div>
                    </div>
                    <div style="text-align: center; background: #E8F5E8; padding: 10px; border-radius: 8px;">
                        <div style="font-weight: bold; color: #2D5A27;">{user['points']}</div>
                        <div style="font-size: 0.8rem; color: #666;">పాయింట్లు</div>
                    </div>
                    <div style="text-align: center; background: #FFEBEE; padding: 10px; border-radius: 8px;">
                        <div style="font-weight: bold; color: #D32F2F;">{user['streak']}</div>
                        <div style="font-size: 0.8rem; color: #666;">స్ట్రీక్</div>
                    </div>
                    <div style="text-align: center; background: #E3F2FD; padding: 10px; border-radius: 8px;">
                        <div style="font-weight: bold; color: #1976D2;">{len(user_recipes)}</div>
                        <div style="font-size: 0.8rem; color: #666;">రెసిపీలు</div>
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)
            
            # Recent recipes
            if user_recipes:
                st.markdown("**🍽️ ఇటీవలి వంటకాలు:**")
                recent_recipes = sorted(user_recipes, key=lambda x: x['created_at'], reverse=True)[:3]
                for recipe in recent_recipes:
                    st.markdown(f"• {recipe['title']} ({recipe['points']} పాయింట్లు)")
            else:
                st.markdown("*ఇంకా రెసిపీలు లేవు*")
            
            # Follow/Unfollow functionality
            if st.session_state.current_user and user_id != st.session_state.current_user:
                followers = st.session_state.user_followers.get(user_id, set())
                is_following = st.session_state.current_user in followers
                
                col1, col2 = st.columns(2)
                with col1:
                    if st.button(
                        f"{'✅ అనుసరిస్తున్నాను' if is_following else '➕ అనుసరించు'}", 
                        key=f"follow_{user_id}_{i}",
                        use_container_width=True
                    ):
                        if is_following:
                            followers.discard(st.session_state.current_user)
                        else:
                            followers.add(st.session_state.current_user)
                        st.session_state.user_followers[user_id] = followers
                        st.rerun()
                
                with col2:
                    st.markdown(f"👥 {len(followers)} అనుచరులు")
            
            st.markdown("---")

def show_list_view(users_list):
    # Create DataFrame for list view
    user_data = []
    for user_id, user in users_list:
        user_recipes = [r for r in st.session_state.recipes if r['user_id'] == user_id]
        followers = len(st.session_state.user_followers.get(user_id, set()))
        
        user_data.append({
            'ర్యాంక్': get_user_rank(user_id),
            'వినియోగదారు': user['username'],
            'ప్రాంతం': user['region'],
            'పాయింట్లు': user['points'],
            'స్ట్రీక్': user['streak'],
            'రెసిపీలు': len(user_recipes),
            'అనుచరులు': followers,
            'చేరిన తేది': user.get('created_at', '')[:10]
        })
    
    df = pd.DataFrame(user_data)
    
    # Display as interactive table
    st.dataframe(
        df,
        use_container_width=True,
        hide_index=True,
        column_config={
            'ర్యాంక్': st.column_config.NumberColumn(
                'ర్యాంక్',
                help='లీడర్‌బోర్డ్‌లో స్థానం',
                format='#%d'
            ),
            'పాయింట్లు': st.column_config.NumberColumn(
                'పాయింట్లు',
                help='మొత్తం సంపాదించిన పాయింట్లు'
            ),
            'స్ట్రీక్': st.column_config.NumberColumn(
                'స్ట్రీక్',
                help='వరుస రోజుల కార్యకలాపాలు'
            )
        }
    )
    
    # Top performers section
    if user_data:
        st.markdown("### 🏆 టాప్ పెర్ఫార్మర్స్")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            top_points = max(user_data, key=lambda x: x['పాయింట్లు'])
            st.markdown(f"""
            <div style="background: linear-gradient(135deg, #FFD700, #FFA500); color: white; padding: 1rem; border-radius: 10px; text-align: center;">
                <h4>⭐ అత్యధిక పాయింట్లు</h4>
                <h3>{top_points['వినియోగదారు']}</h3>
                <p>{top_points['పాయింట్లు']} పాయింట్లు</p>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            top_streak = max(user_data, key=lambda x: x['స్ట్రీక్'])
            st.markdown(f"""
            <div style="background: linear-gradient(135deg, #FF6B35, #F7931E); color: white; padding: 1rem; border-radius: 10px; text-align: center;">
                <h4>🔥 అత్యధిక స్ట్రీక్</h4>
                <h3>{top_streak['వినియోగదారు']}</h3>
                <p>{top_streak['స్ట్రీక్']} రోజులు</p>
            </div>
            """, unsafe_allow_html=True)
        
        with col3:
            top_recipes = max(user_data, key=lambda x: x['రెసిపీలు'])
            st.markdown(f"""
            <div style="background: linear-gradient(135deg, #4CAF50, #2D5A27); color: white; padding: 1rem; border-radius: 10px; text-align: center;">
                <h4>📝 అత్యధిక రెసిపీలు</h4>
                <h3>{top_recipes['వినియోగదారు']}</h3>
                <p>{top_recipes['రెసిపీలు']} రెసిపీలు</p>
            </div>
            """, unsafe_allow_html=True)

def get_user_rank(user_id):
    users_list = list(st.session_state.users.items())
    users_list.sort(key=lambda x: x[1]['points'], reverse=True)
    
    for rank, (uid, _) in enumerate(users_list, 1):
        if uid == user_id:
            return rank
    return len(users_list)

if __name__ == "__main__":
    main()