import streamlit as st
from datetime import datetime
import folium
from streamlit_folium import st_folium

st.set_page_config(page_title="రెసిపీ అప్‌లోడ్ - మన రుచులు", page_icon="📝")

# Points system
POINTS_SYSTEM = {
    'text': 10,
    'image': 20,
    'audio': 25,
    'video': 30,
    'festival_bonus': 15,
    'story': 5
}

# Festival calendar
FESTIVALS = {
    'సంక్రాంతి': {'date': '2024-01-14', 'bonus': 20},
    'ఉగాది': {'date': '2024-04-09', 'bonus': 25},
    'దసరా': {'date': '2024-10-12', 'bonus': 20},
    'దీపావళి': {'date': '2024-11-01', 'bonus': 25},
    'కార్తీక పౌర్ణమి': {'date': '2024-11-15', 'bonus': 15}
}

def validate_telugu_content(text):
    telugu_chars = any('\u0C00' <= char <= '\u0C7F' for char in text)
    return telugu_chars

def get_user_location():
    try:
        import requests
        response = requests.get('https://ipapi.co/json/')
        data = response.json()
        return f"{data.get('city', 'Unknown')}, {data.get('region', 'Unknown')}"
    except:
        return "తెలియని ప్రాంతం"

def show_location_picker():
    st.markdown("#### 🗺️ మ్యాప్‌లో మీ లొకేషన్ ఎంచుకోండి")
    
    # Create map centered on Andhra Pradesh/Telangana
    m = folium.Map(location=[15.9129, 79.7400], zoom_start=7)
    
    # Add click functionality
    m.add_child(folium.ClickForMarker(popup="మీ లొకేషన్"))
    
    map_data = st_folium(m, width=700, height=400)
    
    if map_data['last_clicked']:
        lat, lng = map_data['last_clicked']['lat'], map_data['last_clicked']['lng']
        return f"Lat: {lat:.4f}, Lng: {lng:.4f}"
    
    return get_user_location()

def update_user_stats(user_id, points):
    user = st.session_state.users[user_id]
    user['points'] += points
    
    # Update streak
    today = datetime.now().date()
    if user.get('last_contribution'):
        last_date = datetime.fromisoformat(user['last_contribution']).date()
        if (today - last_date).days == 1:
            user['streak'] += 1
        elif (today - last_date).days > 1:
            user['streak'] = 1
    else:
        user['streak'] = 1
    
    user['last_contribution'] = datetime.now().isoformat()

def main():
    if not st.session_state.current_user:
        st.warning("దయచేసి మొదట లాగిన్ చేయండి")
        return
    
    st.markdown("""
    <div style="background: linear-gradient(135deg, #FF6B35, #F7931E); color: white; padding: 2rem; border-radius: 15px; text-align: center; margin-bottom: 2rem;">
        <h1>📝 కొత్త వంటకం పంచుకోండి</h1>
        <p>మీ అమ్మ చెప్పిన రహస్య రెసిపీని ప్రపంచంతో పంచుకోండి!</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Step 1: Choose input method
    st.markdown("### 📋 దశ 1: ఇన్‌పుట్ పద్ధతిని ఎంచుకోండి")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        if st.button("📝 వచనం\n(10 పాయింట్లు)", key="text_method", use_container_width=True):
            st.session_state.upload_method = 'text'
    
    with col2:
        if st.button("🖼️ చిత్రం\n(20 పాయింట్లు)", key="image_method", use_container_width=True):
            st.session_state.upload_method = 'image'
    
    with col3:
        if st.button("🎤 ఆడియో\n(25 పాయింట్లు)", key="audio_method", use_container_width=True):
            st.session_state.upload_method = 'audio'
    
    with col4:
        if st.button("🎞️ వీడియో\n(30 పాయింట్లు)", key="video_method", use_container_width=True):
            st.session_state.upload_method = 'video'
    
    # Step 2: Upload form based on selected method
    if hasattr(st.session_state, 'upload_method'):
        st.markdown("### 📋 దశ 2: వంటకం వివరాలు")
        
        with st.form("recipe_form"):
            # Basic recipe details
            title = st.text_input("🍽️ వంటకం పేరు *", placeholder="ఉదా: అమ్మ చేసిన పెసరట్టు రెసిపీ")
            content = st.text_area("📝 వంటకం వివరణ *", placeholder="మీ వంటక రెసిపీని తెలుగులో వివరంగా వ్రాయండి...", height=150)
            
            # Location selection
            st.markdown("📍 లొకేషన్ ఎంచుకోండి:")
            location_method = st.radio("", ["🤖 ఆటోమేటిక్ లొకేషన్", "🗺️ మ్యాప్‌లో ఎంచుకోండి", "✍️ మాన్యువల్‌గా టైప్ చేయండి"])
            
            if location_method == "🤖 ఆటోమేటిక్ లొకేషన్":
                location = get_user_location()
                st.info(f"మీ లొకేషన్: {location}")
            elif location_method == "🗺️ మ్యాప్‌లో ఎంచుకోండి":
                location = show_location_picker()
            else:
                location = st.text_input("📍 మీ లొకేషన్ టైప్ చేయండి")
            
            # File upload based on method
            uploaded_file = None
            if st.session_state.upload_method == 'image':
                uploaded_file = st.file_uploader("🖼️ చిత్రం అప్‌లోడ్ చేయండి", type=['png', 'jpg', 'jpeg'])
                if uploaded_file:
                    st.image(uploaded_file, caption="అప్‌లోడ్ చేసిన చిత్రం", use_column_width=True)
            elif st.session_state.upload_method == 'audio':
                uploaded_file = st.file_uploader("🎤 ఆడియో ఫైల్ అప్‌లోడ్ చేయండి", type=['mp3', 'wav', 'ogg'])
                if uploaded_file:
                    st.audio(uploaded_file)
            elif st.session_state.upload_method == 'video':
                uploaded_file = st.file_uploader("🎞️ వీడియో ఫైల్ అప్‌లోడ్ చేయండి", type=['mp4', 'avi', 'mov'])
                if uploaded_file:
                    st.video(uploaded_file)
            
            # Festival special option
            is_festival = st.checkbox("🎉 ఫెస్టివల్ స్పెషల్ రెసిపీ (అదనపు పాయింట్లు!)")
            festival_name = None
            if is_festival:
                festival_name = st.selectbox("🎊 ఫెస్టివల్ ఎంచుకోండి", list(FESTIVALS.keys()))
                st.info(f"🎁 అదనపు {FESTIVALS[festival_name]['bonus']} పాయింట్లు మిలుస్తాయి!")
            
            # Story option
            include_story = st.checkbox("📚 ఈ రెసిపీతో కథ కూడా పంచుకోవాలా? (+5 పాయింట్లు)")
            story_content = ""
            if include_story:
                story_content = st.text_area("📖 మీ కథ వ్రాయండి", placeholder="ఈ వంటకం గురించి మీ అనుభవం, జ్ఞాపకాలు పంచుకోండి...")
            
            # Points calculation preview
            points = POINTS_SYSTEM[st.session_state.upload_method]
            if is_festival and festival_name:
                points += FESTIVALS[festival_name]['bonus']
            if include_story:
                points += POINTS_SYSTEM['story']
            
            st.info(f"🎁 మీరు మొత్తం {points} పాయింట్లు సంపాదిస్తారు!")
            
            if st.form_submit_button("🚀 వంటకం పంచుకోండి", use_container_width=True):
                if not title or not content:
                    st.error("దయచేసి అన్ని అవసరమైన ఫీల్డ్‌లను పూరించండి")
                elif not validate_telugu_content(title) or not validate_telugu_content(content):
                    st.error("దయచేసి తెలుగులో మాత్రమే వ్రాయండి")
                else:
                    # Create recipe
                    recipe = {
                        'id': len(st.session_state.recipes) + 1,
                        'user_id': st.session_state.current_user,
                        'title': title,
                        'content': content,
                        'type': st.session_state.upload_method,
                        'location': location,
                        'points': points,
                        'created_at': datetime.now().isoformat(),
                        'likes': 0,
                        'is_festival': is_festival,
                        'festival_name': festival_name if is_festival else None,
                        'story': story_content if include_story else None,
                        'file_data': uploaded_file.read() if uploaded_file else None
                    }
                    
                    st.session_state.recipes.append(recipe)
                    
                    # Update user points and streak
                    update_user_stats(st.session_state.current_user, points)
                    
                    st.success(f"🎉 విజయవంతంగా జోడించబడింది! మీరు {points} పాయింట్లు సంపాదించారు!")
                    
                    # Clear the upload method
                    if hasattr(st.session_state, 'upload_method'):
                        del st.session_state.upload_method
                    
                    st.balloons()

if __name__ == "__main__":
    main()