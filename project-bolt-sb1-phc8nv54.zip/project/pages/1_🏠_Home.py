import streamlit as st
from datetime import datetime
import plotly.express as px
import plotly.graph_objects as go

st.set_page_config(page_title="హోమ్ - మన రుచులు", page_icon="🏠")

def show_home_dashboard():
    if not st.session_state.current_user:
        st.warning("దయచేసి మొదట లాగిన్ చేయండి")
        return
    
    user = st.session_state.users[st.session_state.current_user]
    
    # Welcome message
    st.markdown(f"""
    <div style="background: linear-gradient(135deg, #FF6B35, #F7931E); color: white; padding: 2rem; border-radius: 15px; text-align: center; margin-bottom: 2rem;">
        <h1>🙏 స్వాగతం, {user['username']}!</h1>
        <p>మీ వంటకాల ప్రయాణంలో ఈరోజు ఏమి కొత్తది?</p>
    </div>
    """, unsafe_allow_html=True)
    
    # User stats dashboard
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            label="🏆 మీ ర్యాంక్",
            value=f"#{get_user_rank(st.session_state.current_user)}",
            delta=None
        )
    
    with col2:
        st.metric(
            label="⭐ మొత్తం పాయింట్లు",
            value=user['points'],
            delta="+10" if user.get('last_points_gained') else None
        )
    
    with col3:
        st.metric(
            label="🔥 కరెంట్ స్ట్రీక్",
            value=f"{user['streak']} రోజులు",
            delta="+1" if user.get('streak_increased') else None
        )
    
    with col4:
        user_recipes = len([r for r in st.session_state.recipes if r['user_id'] == st.session_state.current_user])
        st.metric(
            label="📝 మీ రెసిపీలు",
            value=user_recipes,
            delta="+1" if user.get('new_recipe_added') else None
        )
    
    # Progress charts
    col1, col2 = st.columns(2)
    
    with col1:
        # Points progress chart
        st.markdown("### 📈 పాయింట్లు ప్రోగ్రెస్")
        
        # Sample data for demonstration
        dates = ['Jan', 'Feb', 'Mar', 'Apr', 'May']
        points = [50, 120, 180, 250, user['points']]
        
        fig = px.line(x=dates, y=points, title="మాసిక పాయింట్లు")
        fig.update_traces(line_color='#FF6B35', line_width=3)
        fig.update_layout(
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
        )
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        # Recipe types distribution
        st.markdown("### 🍽️ రెసిపీ రకాలు")
        
        user_recipes_list = [r for r in st.session_state.recipes if r['user_id'] == st.session_state.current_user]
        if user_recipes_list:
            recipe_types = {}
            for recipe in user_recipes_list:
                recipe_type = recipe['type']
                recipe_types[recipe_type] = recipe_types.get(recipe_type, 0) + 1
            
            fig = px.pie(
                values=list(recipe_types.values()),
                names=list(recipe_types.keys()),
                title="మీ రెసిపీ రకాలు"
            )
            fig.update_traces(textposition='inside', textinfo='percent+label')
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("ఇంకా రెసిపీలు లేవు. మొదటి రెసిపీ అప్‌లోడ్ చేయండి!")

def get_user_rank(user_id):
    users_list = list(st.session_state.users.items())
    users_list.sort(key=lambda x: x[1]['points'], reverse=True)
    
    for rank, (uid, _) in enumerate(users_list, 1):
        if uid == user_id:
            return rank
    return len(users_list)

if __name__ == "__main__":
    show_home_dashboard()