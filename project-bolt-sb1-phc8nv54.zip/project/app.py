import streamlit as st
import json
import os
from datetime import datetime, timedelta
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from PIL import Image
import requests
from streamlit_option_menu import option_menu
import folium
from streamlit_folium import st_folium
from streamlit_lottie import st_lottie
import time

# Page configuration
st.set_page_config(
    page_title="మన రుచులు - Mana Ruchulu",
    page_icon="🍛",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for Telugu fonts and styling
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Telugu:wght@300;400;500;600;700&display=swap');

.main-header {
    font-family: 'Noto Sans Telugu', sans-serif;
    background: linear-gradient(135deg, #FF6B35, #F7931E, #2D5A27);
    color: white;
    padding: 2rem;
    border-radius: 15px;
    text-align: center;
    margin-bottom: 2rem;
    box-shadow: 0 8px 32px rgba(255, 107, 53, 0.3);
}

.recipe-card {
    background: white;
    border-radius: 15px;
    padding: 1.5rem;
    margin: 1rem 0;
    box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    border-left: 5px solid #F7931E;
    transition: transform 0.3s ease;
}

.recipe-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 30px rgba(0,0,0,0.15);
}

.user-stats {
    background: linear-gradient(135deg, #FFE5B4, #FFCC70);
    border-radius: 15px;
    padding: 1.5rem;
    margin: 1rem 0;
    text-align: center;
}

.challenge-card {
    background: linear-gradient(135deg, #FF6B35, #F7931E);
    color: white;
    border-radius: 15px;
    padding: 2rem;
    margin: 1rem 0;
    text-align: center;
}

.festival-badge {
    background: linear-gradient(45deg, #FF6B35, #FFD700);
    color: white;
    padding: 0.5rem 1rem;
    border-radius: 20px;
    font-weight: bold;
    display: inline-block;
    margin: 0.5rem;
}

.stButton > button {
    background: linear-gradient(135deg, #FF6B35, #F7931E);
    color: white;
    border: none;
    border-radius: 10px;
    padding: 0.5rem 2rem;
    font-weight: bold;
    transition: all 0.3s ease;
}

.stButton > button:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(255, 107, 53, 0.4);
}

.sidebar .sidebar-content {
    background: linear-gradient(180deg, #FFE5B4, #FFCC70);
}

.metric-card {
    background: white;
    border-radius: 10px;
    padding: 1rem;
    text-align: center;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    margin: 0.5rem;
}

.animated-logo {
    animation: bounce 2s infinite;
}

@keyframes bounce {
    0%, 20%, 50%, 80%, 100% {
        transform: translateY(0);
    }
    40% {
        transform: translateY(-10px);
    }
    60% {
        transform: translateY(-5px);
    }
}

.telugu-text {
    font-family: 'Noto Sans Telugu', sans-serif;
    font-size: 1.2rem;
    line-height: 1.6;
}

.story-container {
    background: linear-gradient(135deg, #E8F5E8, #F0F8F0);
    border-radius: 15px;
    padding: 1.5rem;
    margin: 1rem 0;
    border-left: 4px solid #2D5A27;
}
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'users' not in st.session_state:
    st.session_state.users = {}
if 'recipes' not in st.session_state:
    st.session_state.recipes = []
if 'current_user' not in st.session_state:
    st.session_state.current_user = None
if 'weekly_challenges' not in st.session_state:
    st.session_state.weekly_challenges = []
if 'user_followers' not in st.session_state:
    st.session_state.user_followers = {}
if 'user_stories' not in st.session_state:
    st.session_state.user_stories = {}

# Load Lottie animation
def load_lottie_url(url):
    try:
        r = requests.get(url)
        if r.status_code != 200:
            return None
        return r.json()
    except:
        return None

# Telugu content validation
def validate_telugu_content(text):
    telugu_chars = any('\u0C00' <= char <= '\u0C7F' for char in text)
    return telugu_chars

# Get user location from IP
def get_user_location():
    try:
        response = requests.get('https://ipapi.co/json/')
        data = response.json()
        return f"{data.get('city', 'Unknown')}, {data.get('region', 'Unknown')}"
    except:
        return "తెలియని ప్రాంతం"

# Points system
POINTS_SYSTEM = {
    'text': 10,
    'image': 20,
    'audio': 25,
    'video': 30,
    'festival_bonus': 15,
    'story': 5
}

# Festival calendar
FESTIVALS = {
    'సంక్రాంతి': {'date': '2024-01-14', 'bonus': 20},
    'ఉగాది': {'date': '2024-04-09', 'bonus': 25},
    'దసరా': {'date': '2024-10-12', 'bonus': 20},
    'దీపావళి': {'date': '2024-11-01', 'bonus': 25},
    'కార్తీక పౌర్ణమి': {'date': '2024-11-15', 'bonus': 15}
}

def main():
    # Animated header
    st.markdown("""
    <div class="main-header">
        <h1 class="animated-logo">🍛 మన రుచులు - Mana Ruchulu 🍛</h1>
        <p>తెలుగు వంటకాల అందమైన ప్రపంచం - మన భాష, మన సంస్కృతి, మన రుచులు</p>
    </div>
    """, unsafe_allow_html=True)

    # Sidebar navigation
    with st.sidebar:
        st.markdown("### 🧭 నావిగేషన్")
        
        if st.session_state.current_user:
            user = st.session_state.users[st.session_state.current_user]
            st.markdown(f"""
            <div class="user-stats">
                <h3>🙏 స్వాగతం, {user['username']}!</h3>
                <p>🏆 ర్యాంక్: #{get_user_rank(st.session_state.current_user)}</p>
                <p>⭐ పాయింట్లు: {user['points']}</p>
                <p>🔥 స్ట్రీక్: {user['streak']} రోజులు</p>
                <p>📝 రెసిపీలు: {len([r for r in st.session_state.recipes if r['user_id'] == st.session_state.current_user])}</p>
            </div>
            """, unsafe_allow_html=True)
            
            selected = option_menu(
                menu_title=None,
                options=["🏠 హోమ్", "📝 రెసిపీ అప్‌లోడ్", "🗺️ లొకేషన్ మ్యాప్", "👥 ప్రొఫైల్స్", "🏆 లీడర్‌బోర్డ్", "🎯 వీక్లీ చాలెంజ్", "📚 స్టోరీస్", "🎉 ఫెస్టివల్ స్పెషల్", "⚙️ సెట్టింగ్స్"],
                icons=["house", "upload", "map", "people", "trophy", "target", "book", "gift", "gear"],
                menu_icon="cast",
                default_index=0,
                styles={
                    "container": {"padding": "0!important", "background-color": "#fafafa"},
                    "icon": {"color": "#FF6B35", "font-size": "18px"},
                    "nav-link": {"font-size": "16px", "text-align": "left", "margin": "0px", "--hover-color": "#eee"},
                    "nav-link-selected": {"background-color": "#FF6B35"},
                }
            )
        else:
            selected = option_menu(
                menu_title=None,
                options=["🏠 హోమ్", "🔐 లాగిన్/రిజిస్టర్"],
                icons=["house", "key"],
                menu_icon="cast",
                default_index=0,
            )

    # Main content based on selection
    if selected == "🏠 హోమ్":
        show_home_page()
    elif selected == "🔐 లాగిన్/రిజిస్టర్":
        show_auth_page()
    elif selected == "📝 రెసిపీ అప్‌లోడ్":
        show_recipe_upload_page()
    elif selected == "🗺️ లొకేషన్ మ్యాప్":
        show_location_map_page()
    elif selected == "👥 ప్రొఫైల్స్":
        show_profiles_page()
    elif selected == "🏆 లీడర్‌బోర్డ్":
        show_leaderboard_page()
    elif selected == "🎯 వీక్లీ చాలెంజ్":
        show_weekly_challenge_page()
    elif selected == "📚 స్టోరీస్":
        show_stories_page()
    elif selected == "🎉 ఫెస్టివల్ స్పెషల్":
        show_festival_special_page()
    elif selected == "⚙️ సెట్టింగ్స్":
        show_settings_page()

def show_home_page():
    if not st.session_state.current_user:
        # Welcome page for non-logged users
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            lottie_cooking = load_lottie_url("https://assets5.lottiefiles.com/packages/lf20_kuhijlvz.json")
            if lottie_cooking:
                st_lottie(lottie_cooking, height=300)
            
            st.markdown("""
            <div class="telugu-text" style="text-align: center; padding: 2rem;">
                <h2>🍛 మన రుచులకు స్వాగతం! 🍛</h2>
                <p>వంటకాలు మరియు భాష కలిసిపోయే అందమైన ప్రపంచం, సంస్కృతి కమ్యూనిటీగా మారే చోటు.</p>
                <br>
                <h3>🎁 పాయింట్స్ సిస్టమ్:</h3>
                <div style="display: flex; justify-content: space-around; flex-wrap: wrap;">
                    <div class="metric-card">📝<br>వచనం<br><b>10 పాయింట్లు</b></div>
                    <div class="metric-card">🖼️<br>చిత్రం<br><b>20 పాయింట్లు</b></div>
                    <div class="metric-card">🎤<br>ఆడియో<br><b>25 పాయింట్లు</b></div>
                    <div class="metric-card">🎞️<br>వీడియో<br><b>30 పాయింట్లు</b></div>
                </div>
                <br>
                <p><b>"మన భాష... మన వంట... మన డిజిటల్ చేపలు।"</b></p>
            </div>
            """, unsafe_allow_html=True)
            
            if st.button("🚀 ప్రారంభించండి - ఇవ్వాలా!", key="start_button"):
                st.session_state.show_auth = True
                st.rerun()
    else:
        # Dashboard for logged users
        user = st.session_state.users[st.session_state.current_user]
        
        # User dashboard
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("🏆 మీ ర్యాంక్", f"#{get_user_rank(st.session_state.current_user)}")
        with col2:
            st.metric("⭐ పాయింట్లు", user['points'])
        with col3:
            st.metric("🔥 స్ట్రీక్", f"{user['streak']} రోజులు")
        with col4:
            user_recipes = len([r for r in st.session_state.recipes if r['user_id'] == st.session_state.current_user])
            st.metric("📝 రెసిపీలు", user_recipes)
        
        # Recent activity
        st.markdown("### 📈 మీ ఇటీవలి కార్యకలాపాలు")
        user_recipes = [r for r in st.session_state.recipes if r['user_id'] == st.session_state.current_user]
        user_recipes.sort(key=lambda x: x['created_at'], reverse=True)
        
        if user_recipes:
            for recipe in user_recipes[:3]:
                with st.container():
                    st.markdown(f"""
                    <div class="recipe-card">
                        <h4>{recipe['title']}</h4>
                        <p>📍 {recipe['location']} | ⭐ {recipe['points']} పాయింట్లు | 📅 {recipe['created_at'][:10]}</p>
                        <p>{recipe['content'][:100]}...</p>
                    </div>
                    """, unsafe_allow_html=True)
        else:
            st.info("మీరు ఇంకా రెసిపీలు పోస్ట్ చేయలేదు. మీ మొదటి వంటకం పంచుకోండి! 👆")
        
        # Weekly challenge status
        show_current_challenge_status()
        
        # Recent community recipes
        st.markdown("### 🌟 కమ్యూనిటీ నుండి తాజా రెసిపీలు")
        recent_recipes = sorted(st.session_state.recipes, key=lambda x: x['created_at'], reverse=True)[:5]
        
        for recipe in recent_recipes:
            recipe_user = st.session_state.users.get(recipe['user_id'], {})
            with st.container():
                st.markdown(f"""
                <div class="recipe-card">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <h4>{recipe['title']}</h4>
                            <p>👤 {recipe_user.get('username', 'Unknown')} | 📍 {recipe['location']} | ⭐ {recipe['points']} పాయింట్లు</p>
                            <p>{recipe['content'][:150]}...</p>
                        </div>
                        <div style="text-align: center;">
                            <div style="font-size: 2rem;">{get_type_emoji(recipe['type'])}</div>
                            <small>{get_type_name(recipe['type'])}</small>
                        </div>
                    </div>
                </div>
                """, unsafe_allow_html=True)

def show_auth_page():
    st.markdown("### 🔐 లాగిన్ / రిజిస్టర్")
    
    tab1, tab2 = st.tabs(["లాగిన్", "రిజిస్టర్"])
    
    with tab1:
        with st.form("login_form"):
            st.markdown("#### 🚪 మీ ఖాతాలో ప్రవేశించండి")
            email = st.text_input("📧 ఇమెయిల్")
            password = st.text_input("🔒 పాస్‌వర్డ్", type="password")
            
            if st.form_submit_button("లాగిన్"):
                if login_user(email, password):
                    st.success("విజయవంతంగా లాగిన్ అయ్యారు! 🎉")
                    time.sleep(1)
                    st.rerun()
                else:
                    st.error("తప్పుడు ఇమెయిల్ లేదా పాస్‌వర్డ్")
    
    with tab2:
        with st.form("register_form"):
            st.markdown("#### 📝 కొత్త ఖాతా సృష్టించండి")
            username = st.text_input("👤 వినియోగదారు పేరు")
            email = st.text_input("📧 ఇమెయిల్")
            password = st.text_input("🔒 పాస్‌వర్డ్", type="password")
            region = st.text_input("📍 మీ ప్రాంతం", value=get_user_location())
            
            if st.form_submit_button("రిజిస్టర్"):
                if register_user(username, email, password, region):
                    st.success("విజయవంతంగా నమోదు చేయబడింది! 🎉")
                    time.sleep(1)
                    st.rerun()
                else:
                    st.error("రిజిస్ట్రేషన్ విఫలమైంది. దయచేసి మళ్లీ ప్రయత్నించండి.")

def show_recipe_upload_page():
    if not st.session_state.current_user:
        st.warning("దయచేసి మొదట లాగిన్ చేయండి")
        return
    
    st.markdown("### 📝 కొత్త వంటకం పంచుకోండి")
    
    # Step 1: Choose input method
    st.markdown("#### 📋 దశ 1: ఇన్‌పుట్ పద్ధతిని ఎంచుకోండి")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        if st.button("📝 వచనం\n(10 పాయింట్లు)", key="text_method"):
            st.session_state.upload_method = 'text'
    
    with col2:
        if st.button("🖼️ చిత్రం\n(20 పాయింట్లు)", key="image_method"):
            st.session_state.upload_method = 'image'
    
    with col3:
        if st.button("🎤 ఆడియో\n(25 పాయింట్లు)", key="audio_method"):
            st.session_state.upload_method = 'audio'
    
    with col4:
        if st.button("🎞️ వీడియో\n(30 పాయింట్లు)", key="video_method"):
            st.session_state.upload_method = 'video'
    
    # Step 2: Upload form based on selected method
    if hasattr(st.session_state, 'upload_method'):
        st.markdown("#### 📋 దశ 2: వంటకం వివరాలు")
        
        with st.form("recipe_form"):
            title = st.text_input("🍽️ వంటకం పేరు *", placeholder="ఉదా: అమ్మ చేసిన పెసరట్టు రెసిపీ")
            content = st.text_area("📝 వంటకం వివరణ *", placeholder="మీ వంటక రెసిపీని తెలుగులో వివరంగా వ్రాయండి...", height=150)
            
            # Location selection with map
            st.markdown("📍 లొకేషన్ ఎంచుకోండి:")
            location_method = st.radio("", ["🤖 ఆటోమేటిక్ లొకేషన్", "🗺️ మ్యాప్‌లో ఎంచుకోండి", "✍️ మాన్యువల్‌గా టైప్ చేయండి"])
            
            if location_method == "🤖 ఆటోమేటిక్ లొకేషన్":
                location = get_user_location()
                st.info(f"మీ లొకేషన్: {location}")
            elif location_method == "🗺️ మ్యాప్‌లో ఎంచుకోండి":
                location = show_location_picker()
            else:
                location = st.text_input("📍 మీ లొకేషన్ టైప్ చేయండి")
            
            # File upload based on method
            uploaded_file = None
            if st.session_state.upload_method == 'image':
                uploaded_file = st.file_uploader("🖼️ చిత్రం అప్‌లోడ్ చేయండి", type=['png', 'jpg', 'jpeg'])
            elif st.session_state.upload_method == 'audio':
                uploaded_file = st.file_uploader("🎤 ఆడియో ఫైల్ అప్‌లోడ్ చేయండి", type=['mp3', 'wav', 'ogg'])
            elif st.session_state.upload_method == 'video':
                uploaded_file = st.file_uploader("🎞️ వీడియో ఫైల్ అప్‌లోడ్ చేయండి", type=['mp4', 'avi', 'mov'])
            
            # Festival special option
            is_festival = st.checkbox("🎉 ఫెస్టివల్ స్పెషల్ రెసిపీ (అదనపు పాయింట్లు!)")
            if is_festival:
                festival_name = st.selectbox("🎊 ఫెస్టివల్ ఎంచుకోండి", list(FESTIVALS.keys()))
            
            # Story option
            include_story = st.checkbox("📚 ఈ రెసిపీతో కథ కూడా పంచుకోవాలా?")
            story_content = ""
            if include_story:
                story_content = st.text_area("📖 మీ కథ వ్రాయండి", placeholder="ఈ వంటకం గురించి మీ అనుభవం, జ్ఞాపకాలు పంచుకోండి...")
            
            if st.form_submit_button("🚀 వంటకం పంచుకోండి"):
                if not title or not content:
                    st.error("దయచేసి అన్ని అవసరమైన ఫీల్డ్‌లను పూరించండి")
                elif not validate_telugu_content(title) or not validate_telugu_content(content):
                    st.error("దయచేసి తెలుగులో మాత్రమే వ్రాయండి")
                else:
                    # Calculate points
                    points = POINTS_SYSTEM[st.session_state.upload_method]
                    if is_festival:
                        points += FESTIVALS[festival_name]['bonus']
                    if include_story:
                        points += POINTS_SYSTEM['story']
                    
                    # Create recipe
                    recipe = {
                        'id': len(st.session_state.recipes) + 1,
                        'user_id': st.session_state.current_user,
                        'title': title,
                        'content': content,
                        'type': st.session_state.upload_method,
                        'location': location,
                        'points': points,
                        'created_at': datetime.now().isoformat(),
                        'likes': 0,
                        'is_festival': is_festival,
                        'festival_name': festival_name if is_festival else None,
                        'story': story_content if include_story else None,
                        'file_data': uploaded_file.read() if uploaded_file else None
                    }
                    
                    st.session_state.recipes.append(recipe)
                    
                    # Update user points and streak
                    update_user_stats(st.session_state.current_user, points)
                    
                    st.success(f"🎉 విజయవంతంగా జోడించబడింది! మీరు {points} పాయింట్లు సంపాదించారు!")
                    
                    # Clear the upload method
                    if hasattr(st.session_state, 'upload_method'):
                        del st.session_state.upload_method
                    
                    time.sleep(2)
                    st.rerun()

def show_location_map_page():
    st.markdown("### 🗺️ లొకేషన్ మ్యాప్ - ప్రాంతవారీ వంటకాలు")
    
    # Create a map centered on Andhra Pradesh/Telangana
    m = folium.Map(location=[15.9129, 79.7400], zoom_start=7)
    
    # Add markers for each recipe location
    location_recipes = {}
    for recipe in st.session_state.recipes:
        location = recipe['location']
        if location not in location_recipes:
            location_recipes[location] = []
        location_recipes[location].append(recipe)
    
    # Add markers to map (simplified - in real app, you'd geocode locations)
    sample_locations = {
        'Hyderabad, Telangana': [17.3850, 78.4867],
        'Vijayawada, Andhra Pradesh': [16.5062, 80.6480],
        'Visakhapatnam, Andhra Pradesh': [17.6868, 83.2185],
        'Tirupati, Andhra Pradesh': [13.6288, 79.4192],
        'Warangal, Telangana': [17.9689, 79.5941]
    }
    
    for location, coords in sample_locations.items():
        if location in location_recipes:
            recipes_count = len(location_recipes[location])
            popup_text = f"📍 {location}<br>🍽️ {recipes_count} వంటకాలు"
            folium.Marker(
                coords,
                popup=popup_text,
                icon=folium.Icon(color='orange', icon='cutlery', prefix='fa')
            ).add_to(m)
    
    # Display map
    map_data = st_folium(m, width=700, height=500)
    
    # Show recipes from selected location
    if map_data['last_object_clicked_popup']:
        st.markdown("### 🍽️ ఎంచుకున్న ప్రాంతపు వంటకాలు")
        # Display recipes from clicked location
        # This would be implemented based on the clicked location

def show_profiles_page():
    st.markdown("### 👥 కమ్యూనిటీ ప్రొఫైల్స్")
    
    # Search and filter options
    col1, col2 = st.columns([2, 1])
    with col1:
        search_term = st.text_input("🔍 వినియోగదారుని వెతకండి", placeholder="పేరు లేదా ప్రాంతం వ్రాయండి...")
    with col2:
        sort_by = st.selectbox("🔄 క్రమబద్ధీకరణ", ["పాయింట్లు", "రెసిపీలు", "స్ట్రీక్"])
    
    # Get all users and sort
    users_list = list(st.session_state.users.items())
    if sort_by == "పాయింట్లు":
        users_list.sort(key=lambda x: x[1]['points'], reverse=True)
    elif sort_by == "రెసిపీలు":
        users_list.sort(key=lambda x: len([r for r in st.session_state.recipes if r['user_id'] == x[0]]), reverse=True)
    elif sort_by == "స్ట్రీక్":
        users_list.sort(key=lambda x: x[1]['streak'], reverse=True)
    
    # Display user profiles
    for user_id, user in users_list:
        if search_term and search_term.lower() not in user['username'].lower() and search_term.lower() not in user['region'].lower():
            continue
        
        user_recipes = [r for r in st.session_state.recipes if r['user_id'] == user_id]
        
        with st.container():
            col1, col2, col3 = st.columns([1, 2, 1])
            
            with col1:
                st.markdown(f"""
                <div style="text-align: center; padding: 1rem; background: linear-gradient(135deg, #FFE5B4, #FFCC70); border-radius: 15px;">
                    <div style="font-size: 3rem;">👤</div>
                    <h4>{user['username']}</h4>
                    <p>📍 {user['region']}</p>
                </div>
                """, unsafe_allow_html=True)
            
            with col2:
                st.markdown(f"""
                <div class="recipe-card">
                    <h4>📊 గణాంకాలు</h4>
                    <div style="display: flex; justify-content: space-around;">
                        <div><b>🏆 ర్యాంక్:</b> #{get_user_rank(user_id)}</div>
                        <div><b>⭐ పాయింట్లు:</b> {user['points']}</div>
                        <div><b>🔥 స్ట్రీక్:</b> {user['streak']}</div>
                        <div><b>📝 రెసిపీలు:</b> {len(user_recipes)}</div>
                    </div>
                    <br>
                    <h5>🍽️ ఇటీవలి వంటకాలు:</h5>
                </div>
                """, unsafe_allow_html=True)
                
                # Show recent recipes
                recent_recipes = sorted(user_recipes, key=lambda x: x['created_at'], reverse=True)[:3]
                for recipe in recent_recipes:
                    st.markdown(f"• {recipe['title']} ({recipe['points']} పాయింట్లు)")
            
            with col3:
                # Follow/Unfollow button
                if st.session_state.current_user and user_id != st.session_state.current_user:
                    followers = st.session_state.user_followers.get(user_id, set())
                    is_following = st.session_state.current_user in followers
                    
                    if st.button(f"{'✅ అనుసరిస్తున్నాను' if is_following else '➕ అనుసరించు'}", key=f"follow_{user_id}"):
                        if is_following:
                            followers.discard(st.session_state.current_user)
                        else:
                            followers.add(st.session_state.current_user)
                        st.session_state.user_followers[user_id] = followers
                        st.rerun()
                    
                    st.markdown(f"👥 {len(followers)} అనుచరులు")
            
            st.markdown("---")

def show_leaderboard_page():
    st.markdown("### 🏆 లీడర్‌బోర్డ్ - టాప్ కుకింగ్ మాస్టర్స్")
    
    # Get sorted users
    users_list = list(st.session_state.users.items())
    users_list.sort(key=lambda x: x[1]['points'], reverse=True)
    
    # Top 3 podium
    if len(users_list) >= 3:
        st.markdown("### 🥇🥈🥉 టాప్ 3 విజేతలు")
        col1, col2, col3 = st.columns(3)
        
        positions = [1, 0, 2]  # Second, First, Third for visual effect
        cols = [col2, col1, col3]
        medals = ['🥈', '🥇', '🥉']
        
        for i, (pos, col, medal) in enumerate(zip(positions, cols, medals)):
            if pos < len(users_list):
                user_id, user = users_list[pos]
                with col:
                    st.markdown(f"""
                    <div style="text-align: center; padding: 1.5rem; background: linear-gradient(135deg, #FFD700, #FFA500); border-radius: 15px; margin: 1rem 0;">
                        <div style="font-size: 4rem;">{medal}</div>
                        <h3>{user['username']}</h3>
                        <p><b>{user['points']}</b> పాయింట్లు</p>
                        <p>🔥 {user['streak']} రోజుల స్ట్రీక్</p>
                        <p>📍 {user['region']}</p>
                    </div>
                    """, unsafe_allow_html=True)
    
    # Full leaderboard
    st.markdown("### 📊 పూర్తి లీడర్‌బోర్డ్")
    
    for rank, (user_id, user) in enumerate(users_list, 1):
        user_recipes = len([r for r in st.session_state.recipes if r['user_id'] == user_id])
        
        # Rank color coding
        if rank == 1:
            bg_color = "linear-gradient(135deg, #FFD700, #FFA500)"
        elif rank == 2:
            bg_color = "linear-gradient(135deg, #C0C0C0, #A0A0A0)"
        elif rank == 3:
            bg_color = "linear-gradient(135deg, #CD7F32, #B8860B)"
        else:
            bg_color = "linear-gradient(135deg, #F0F0F0, #E0E0E0)"
        
        st.markdown(f"""
        <div style="background: {bg_color}; padding: 1rem; margin: 0.5rem 0; border-radius: 10px; display: flex; justify-content: space-between; align-items: center;">
            <div style="display: flex; align-items: center;">
                <div style="font-size: 2rem; margin-right: 1rem;">#{rank}</div>
                <div>
                    <h4 style="margin: 0;">{user['username']}</h4>
                    <p style="margin: 0; opacity: 0.8;">📍 {user['region']}</p>
                </div>
            </div>
            <div style="text-align: right;">
                <div><b>⭐ {user['points']}</b> పాయింట్లు</div>
                <div>🔥 {user['streak']} స్ట్రీక్ | 📝 {user_recipes} రెసిపీలు</div>
            </div>
        </div>
        """, unsafe_allow_html=True)

def show_weekly_challenge_page():
    st.markdown("### 🎯 వీక్లీ చాలెంజ్")
    
    # Current week challenge
    current_challenge = get_current_weekly_challenge()
    
    st.markdown(f"""
    <div class="challenge-card">
        <h2>🏆 ఈ వారపు చాలెంజ్</h2>
        <h3>{current_challenge['title']}</h3>
        <p>{current_challenge['description']}</p>
        <div style="display: flex; justify-content: space-between; margin-top: 1rem;">
            <div><b>🎁 బహుమతి:</b> {current_challenge['reward']} పాయింట్లు</div>
            <div><b>⏰ గడువు:</b> {current_challenge['end_date']}</div>
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    # Challenge participation
    if st.session_state.current_user:
        user_participation = get_user_challenge_participation(st.session_state.current_user, current_challenge['id'])
        
        if user_participation:
            st.success("🎉 మీరు ఈ చాలెంజ్‌లో పాల్గొన్నారు!")
            st.markdown(f"**మీ సబ్మిషన్:** {user_participation['submission_title']}")
        else:
            st.info("ఈ చాలెంజ్‌లో పాల్గొనడానికి సంబంధిత రెసిపీని అప్‌లోడ్ చేయండి!")
    
    # Challenge leaderboard
    st.markdown("### 🏅 చాలెంజ్ లీడర్‌బోర్డ్")
    challenge_participants = get_challenge_participants(current_challenge['id'])
    
    for rank, participant in enumerate(challenge_participants, 1):
        user = st.session_state.users.get(participant['user_id'], {})
        st.markdown(f"""
        <div class="recipe-card">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <h4>#{rank} {user.get('username', 'Unknown')}</h4>
                    <p>{participant['submission_title']}</p>
                </div>
                <div style="text-align: right;">
                    <div><b>{participant['points']}</b> పాయింట్లు</div>
                    <div>👍 {participant['likes']} లైక్‌లు</div>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)

def show_stories_page():
    st.markdown("### 📚 కమ్యూనిటీ స్టోరీస్")
    
    # Get all recipes with stories
    recipes_with_stories = [r for r in st.session_state.recipes if r.get('story')]
    
    if not recipes_with_stories:
        st.info("ఇంకా ఎవరూ కథలు పంచుకోలేదు. మీరే మొదటివారు అవ్వండి!")
        return
    
    # Display stories
    for recipe in sorted(recipes_with_stories, key=lambda x: x['created_at'], reverse=True):
        user = st.session_state.users.get(recipe['user_id'], {})
        
        with st.container():
            st.markdown(f"""
            <div class="story-container">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                    <div>
                        <h4>📖 {recipe['title']}</h4>
                        <p>👤 {user.get('username', 'Unknown')} | 📍 {recipe['location']} | 📅 {recipe['created_at'][:10]}</p>
                    </div>
                    <div style="font-size: 2rem;">{get_type_emoji(recipe['type'])}</div>
                </div>
                <div style="background: white; padding: 1rem; border-radius: 10px; margin: 1rem 0;">
                    <h5>🍽️ రెసిపీ:</h5>
                    <p>{recipe['content'][:200]}...</p>
                </div>
                <div style="background: #F0F8F0; padding: 1rem; border-radius: 10px; border-left: 4px solid #2D5A27;">
                    <h5>📚 కథ:</h5>
                    <p style="font-style: italic;">{recipe['story']}</p>
                </div>
                <div style="margin-top: 1rem; text-align: right;">
                    <button style="background: none; border: none; color: #FF6B35; cursor: pointer;">
                        ❤️ {recipe['likes']} లైక్‌లు
                    </button>
                </div>
            </div>
            """, unsafe_allow_html=True)
            
            st.markdown("---")

def show_festival_special_page():
    st.markdown("### 🎉 ఫెస్టివల్ స్పెషల్ రెసిపీలు")
    
    # Current and upcoming festivals
    st.markdown("#### 🗓️ ఈ సంవత్సరపు ఫెస్టివల్‌లు")
    
    col1, col2 = st.columns(2)
    for i, (festival, details) in enumerate(FESTIVALS.items()):
        with col1 if i % 2 == 0 else col2:
            st.markdown(f"""
            <div class="festival-badge">
                <h4>{festival}</h4>
                <p>📅 {details['date']}</p>
                <p>🎁 అదనపు {details['bonus']} పాయింట్లు!</p>
            </div>
            """, unsafe_allow_html=True)
    
    # Festival recipes
    st.markdown("#### 🍽️ ఫెస్టివల్ రెసిపీలు")
    
    festival_recipes = [r for r in st.session_state.recipes if r.get('is_festival')]
    
    if festival_recipes:
        for recipe in sorted(festival_recipes, key=lambda x: x['created_at'], reverse=True):
            user = st.session_state.users.get(recipe['user_id'], {})
            
            st.markdown(f"""
            <div class="recipe-card" style="border-left: 5px solid #FFD700;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <div class="festival-badge" style="display: inline-block; margin-bottom: 0.5rem;">
                            🎊 {recipe.get('festival_name', 'ఫెస్టివల్')} స్పెషల్
                        </div>
                        <h4>{recipe['title']}</h4>
                        <p>👤 {user.get('username', 'Unknown')} | 📍 {recipe['location']}</p>
                        <p>{recipe['content'][:150]}...</p>
                    </div>
                    <div style="text-align: center;">
                        <div style="font-size: 2rem;">{get_type_emoji(recipe['type'])}</div>
                        <div><b>⭐ {recipe['points']}</b> పాయింట్లు</div>
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)
    else:
        st.info("ఇంకా ఫెస్టివల్ రెసిపీలు లేవు. మీరే మొదటి ఫెస్టివల్ రెసిపీ పంచుకోండి!")

def show_settings_page():
    if not st.session_state.current_user:
        st.warning("దయచేసి మొదట లాగిన్ చేయండి")
        return
    
    st.markdown("### ⚙️ సెట్టింగ్స్")
    
    user = st.session_state.users[st.session_state.current_user]
    
    # Profile settings
    st.markdown("#### 👤 ప్రొఫైల్ సెట్టింగ్స్")
    
    with st.form("profile_settings"):
        new_username = st.text_input("వినియోగదారు పేరు", value=user['username'])
        new_region = st.text_input("ప్రాంతం", value=user['region'])
        
        if st.form_submit_button("అప్‌డేట్ చేయండి"):
            st.session_state.users[st.session_state.current_user]['username'] = new_username
            st.session_state.users[st.session_state.current_user]['region'] = new_region
            st.success("ప్రొఫైల్ అప్‌డేట్ చేయబడింది!")
    
    # Account actions
    st.markdown("#### 🔐 ఖాతా చర్యలు")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("🚪 లాగౌట్"):
            st.session_state.current_user = None
            st.success("విజయవంతంగా లాగౌట్ అయ్యారు!")
            time.sleep(1)
            st.rerun()
    
    with col2:
        if st.button("🗑️ ఖాతా తొలగించు", type="secondary"):
            if st.checkbox("నేను ఖాతా తొలగింపును ధృవీకరిస్తున్నాను"):
                # Delete user account
                del st.session_state.users[st.session_state.current_user]
                st.session_state.current_user = None
                st.success("ఖాతా తొలగించబడింది!")
                time.sleep(1)
                st.rerun()

# Helper functions
def login_user(email, password):
    for user_id, user in st.session_state.users.items():
        if user['email'] == email:
            st.session_state.current_user = user_id
            return True
    return False

def register_user(username, email, password, region):
    # Check if user already exists
    for user in st.session_state.users.values():
        if user['email'] == email or user['username'] == username:
            return False
    
    # Create new user
    user_id = f"user_{len(st.session_state.users) + 1}"
    st.session_state.users[user_id] = {
        'username': username,
        'email': email,
        'region': region,
        'points': 0,
        'streak': 0,
        'last_contribution': None,
        'created_at': datetime.now().isoformat()
    }
    
    st.session_state.current_user = user_id
    return True

def update_user_stats(user_id, points):
    user = st.session_state.users[user_id]
    user['points'] += points
    
    # Update streak
    today = datetime.now().date()
    if user['last_contribution']:
        last_date = datetime.fromisoformat(user['last_contribution']).date()
        if (today - last_date).days == 1:
            user['streak'] += 1
        elif (today - last_date).days > 1:
            user['streak'] = 1
    else:
        user['streak'] = 1
    
    user['last_contribution'] = datetime.now().isoformat()

def get_user_rank(user_id):
    users_list = list(st.session_state.users.items())
    users_list.sort(key=lambda x: x[1]['points'], reverse=True)
    
    for rank, (uid, _) in enumerate(users_list, 1):
        if uid == user_id:
            return rank
    return len(users_list)

def get_type_emoji(recipe_type):
    emojis = {
        'text': '📝',
        'image': '🖼️',
        'audio': '🎤',
        'video': '🎞️'
    }
    return emojis.get(recipe_type, '📝')

def get_type_name(recipe_type):
    names = {
        'text': 'వచనం',
        'image': 'చిత్రం',
        'audio': 'ఆడియో',
        'video': 'వీడియో'
    }
    return names.get(recipe_type, 'వచనం')

def show_location_picker():
    # Simple location picker with map
    m = folium.Map(location=[15.9129, 79.7400], zoom_start=7)
    
    # Add click functionality
    m.add_child(folium.ClickForMarker(popup="మీ లొకేషన్"))
    
    map_data = st_folium(m, width=700, height=400)
    
    if map_data['last_clicked']:
        lat, lng = map_data['last_clicked']['lat'], map_data['last_clicked']['lng']
        return f"Lat: {lat:.4f}, Lng: {lng:.4f}"
    
    return get_user_location()

def get_current_weekly_challenge():
    # Sample weekly challenge
    return {
        'id': 'week_1',
        'title': '🥘 పారంపరిక కూరలు వీక్',
        'description': 'మీ అమ్మ/అమ్మమ్మ చేసే పారంపరిక కూర రెసిపీని పంచుకోండి',
        'reward': 50,
        'end_date': '2024-01-21',
        'type': 'traditional_curry'
    }

def get_user_challenge_participation(user_id, challenge_id):
    # Check if user participated in challenge
    for recipe in st.session_state.recipes:
        if recipe['user_id'] == user_id and recipe.get('challenge_id') == challenge_id:
            return {
                'submission_title': recipe['title'],
                'points': recipe['points']
            }
    return None

def get_challenge_participants(challenge_id):
    # Get all participants for a challenge
    participants = []
    for recipe in st.session_state.recipes:
        if recipe.get('challenge_id') == challenge_id:
            participants.append({
                'user_id': recipe['user_id'],
                'submission_title': recipe['title'],
                'points': recipe['points'],
                'likes': recipe['likes']
            })
    
    return sorted(participants, key=lambda x: x['points'], reverse=True)

def show_current_challenge_status():
    if st.session_state.current_user:
        current_challenge = get_current_weekly_challenge()
        participation = get_user_challenge_participation(st.session_state.current_user, current_challenge['id'])
        
        if participation:
            st.success(f"🎯 వీక్లీ చాలెంజ్‌లో పాల్గొన్నారు: {participation['submission_title']}")
        else:
            st.info(f"🎯 ఈ వారపు చాలెంజ్: {current_challenge['title']} - పాల్గొనండి!")

if __name__ == "__main__":
    main()